<template>
  <div class="Page2-1-box">
    Page2-1
  </div>
</template>

<script>
export default {
  name: 'Page2-1',
  // mixins: [],
  components: {},
  // props,
  data() {
    return {}
  },
  created() {},
  mounted() {},
  methods: {},
  computed: {},
  watch: {}
  // updated () {},
  // beforeRouteUpdate () {},
  // beforeDestroy () {},
  // destroyed () {},
  // filters: {},
}
</script>

<style lang="scss" scoped></style>
