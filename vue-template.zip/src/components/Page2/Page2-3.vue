<template>
  <div class="Page2-3-box">
    Page2-3
  </div>
</template>

<script>
export default {
  name: 'Page2-3',
  // mixins: [],
  components: {},
  // props,
  data() {
    return {}
  },
  created() {},
  mounted() {},
  methods: {},
  computed: {},
  watch: {}
  // updated () {},
  // beforeRouteUpdate () {},
  // beforeDestroy () {},
  // destroyed () {},
  // filters: {},
}
</script>

<style lang="scss" scoped></style>
