<template>
  <i :class="iconName"></i>
</template>

<script>
export default {
  name: 'Iconfont',
  props: ['iconName']
}
</script>

<style scoped></style>
