import Vue from 'vue'
import Iconfont from '../components/common/Iconfont.vue'
import GlobalDialog from '../components/common/GlobalDialog.vue'
Vue.component('Iconfont', Iconfont)
Vue.component('GlobalDialog', GlobalDialog)
