import // GET_TRANSITION_RATE_ACTION
'./actions-types'
export default {
  // 获取目标汇率
  // async [GET_TRANSITION_RATE_ACTION] ({commit}, {params, activeConvertCurrencyObj}) {
  //   const data = await getTransitionCurrencyRateAjax(params);
  //   if (!data) return false;
  //   commit('CHANGE_CURRENCY_RATE_LIST', {
  //     currencyRateList: data.data,
  //     activeConvertCurrencyObj
  //   });
  // }
}
