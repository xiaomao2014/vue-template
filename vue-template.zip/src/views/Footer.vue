<template>
  <div class="footer-box">
    底部
  </div>
</template>

<script>
export default {
  name: 'Footer',
  // mixins: [],
  // components: {},
  // props,
  data() {
    return {}
  },
  created() {},
  mounted() {},
  methods: {},
  computed: {},
  watch: {}
  // updated () {},
  // beforeRouteUpdate () {},
  // beforeDestroy () {},
  // destroyed () {},
  // filters: {},
}
</script>

<style lang="scss" scoped>
.footer-box {
  width: 100%;
  height: 200px;
  box-sizing: border-box;
  min-width: 1100px;
  background-color: #ffeebc;
}
</style>
